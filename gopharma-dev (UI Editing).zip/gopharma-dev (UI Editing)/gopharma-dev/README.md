# GoPharma

Medicine shopping center.

## Integrating with Android Studio

1. Clone this repository to a folder
2. Open the folder in Android Studio
3. On the notification, there should be notification about framework detected
4. Click "configure" and setup the frameworks
5. Run ```flutter pub get```
