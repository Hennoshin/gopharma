const String routeHome = "/home";
const String routeProfile = "/home/profile";
const String routeLogin = "/login";
const String routeResetPassword = "/login/password_reset";
const String routeRegister = "/register";
const String routeOTP = "/otp";


///ADMIN
const String routeHomeAdmin = "/home_admin";
const String addBarang = "/add_barang";
const String editBarang = "/edit_barang";
